create procedure Attempt_Question_Answer_Get
	@AttemptID int
	as
begin
select Question.Value, Answer.Value from Attempt_Question_Answer 
inner join Question on Attempt_Question_Answer.QuestionID=Question.ID 
inner join Answer on Attempt_Question_Answer.AnswerID=Answer.ID
where Attempt_Question_Answer.ID=@AttemptID
end

go

