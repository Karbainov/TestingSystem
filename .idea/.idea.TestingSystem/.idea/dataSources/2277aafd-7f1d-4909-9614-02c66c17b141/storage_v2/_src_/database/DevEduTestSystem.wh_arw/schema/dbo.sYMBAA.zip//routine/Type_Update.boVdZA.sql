CREATE PROC Type_Update
	@TypeId int,
	@Name nvarchar(30)
AS
BEGIN
UPDATE Type
SET Name = @Name
WHERE ID = @TypeId
END
go

