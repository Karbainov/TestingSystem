CREATE PROCEDURE Attempt_Question_Answer_GetById
	@Id int
AS
BEGIN
    SELECT *
    FROM Attempt_Question_Answer
    WHERE ID = @Id;
END;
go

