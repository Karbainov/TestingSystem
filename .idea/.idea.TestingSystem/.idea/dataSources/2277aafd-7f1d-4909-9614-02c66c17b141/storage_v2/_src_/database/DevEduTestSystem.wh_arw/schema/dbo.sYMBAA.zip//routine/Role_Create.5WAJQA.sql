CREATE procedure [dbo].[Role_Create]
	@Name nvarchar(30)
	as
begin
insert into Role values(@Name)
end
go

