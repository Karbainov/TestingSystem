CREATE PROCEDURE Teacher_Group_GetByUserID
@UserID int
AS
BEGIN
SELECT * FROM Teacher_Group WHERE UserID=@UserID
END
go

