CREATE PROCEDURE User_Position
AS
BEGIN
SELECT [User].FirstName +'  '+ [User].LastName AS FIO, [Role].Name AS Position 
FROM [User]
INNER JOIN User_Role ON [User].ID=User_Role.UserID
INNER JOIN [Role] ON User_Role.RoleID=[Role].ID
ORDER BY [Role].Name
END
go

