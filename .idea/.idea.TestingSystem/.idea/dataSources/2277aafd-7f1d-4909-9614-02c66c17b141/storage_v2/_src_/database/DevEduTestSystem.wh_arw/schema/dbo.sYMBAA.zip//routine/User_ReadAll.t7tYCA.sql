create procedure User_ReadAll as
begin 
select * from [User] 
end
go

