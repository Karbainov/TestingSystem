CREATE PROCEDURE Test_Group_DeleteGetByGroupID_TestID
@idGroup INT,
@idTest INT
AS
	BEGIN 
	DELETE Test_Group 
	WHERE(GroupID=@idGroup AND TestID=@idTest);
END
go

