CREATE PROCEDURE Student_Group_GetAll
AS
BEGIN 
SELECT * FROM Student_Group
END
go

