
CREATE PROCEDURE Attempt_GetByTestID
     @testID   INT
        
AS
BEGIN
    SELECT *    FROM Attempt
    WHERE TestID = @testID  ;
END;
go

