CREATE PROCEDURE Test_Group_DeleteId
	@idTestsGroup INT
	AS
	BEGIN 
	DELETE Test_Group 
	WHERE(ID=@idTestsGroup);
	END
go

