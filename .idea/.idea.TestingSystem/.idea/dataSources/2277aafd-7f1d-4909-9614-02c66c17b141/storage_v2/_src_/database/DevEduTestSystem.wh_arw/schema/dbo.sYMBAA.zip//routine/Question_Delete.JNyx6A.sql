CREATE PROCEDURE Question_Delete @Id int AS
BEGIN
DELETE Question
WHERE ID = @Id
END;
go

