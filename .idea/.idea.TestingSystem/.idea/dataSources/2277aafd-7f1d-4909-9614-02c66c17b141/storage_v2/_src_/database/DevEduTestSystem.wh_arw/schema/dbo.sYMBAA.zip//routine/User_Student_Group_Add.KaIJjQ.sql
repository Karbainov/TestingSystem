create procedure User_Student_Group_Add
	@GroupID int,
	@FirstName nvarchar(30),
	@LastName nvarchar(30),
	@BirthDate date,
	@Login nvarchar(30),
	@Password nvarchar(30),
	@Email nvarchar(60),
	@Phone nvarchar(12)
	as
begin
insert into [User] values(@FirstName,@LastName,@BirthDate,@Login,@Password,@Email,@Phone)
insert into Student_Group values((select ID From [User] where [User].Login = @Login),@GroupID)   
end
go

