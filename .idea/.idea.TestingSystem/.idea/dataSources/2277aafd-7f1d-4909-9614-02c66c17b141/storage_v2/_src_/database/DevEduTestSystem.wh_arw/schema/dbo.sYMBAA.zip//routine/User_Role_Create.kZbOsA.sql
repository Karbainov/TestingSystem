CREATE procedure [dbo].[User_Role_Create]
	@UserID int,
	@RoleID int
	as
begin
insert into User_Role(UserID,RoleID) values (@UserID,@RoleID)
end
go

