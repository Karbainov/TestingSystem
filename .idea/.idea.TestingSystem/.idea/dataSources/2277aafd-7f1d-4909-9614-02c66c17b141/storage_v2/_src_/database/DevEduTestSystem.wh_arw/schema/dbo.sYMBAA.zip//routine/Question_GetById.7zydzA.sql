CREATE PROCEDURE Question_GetById @Id int AS
BEGIN
SELECT * FROM Question WHERE ID = @Id;
END;
go

