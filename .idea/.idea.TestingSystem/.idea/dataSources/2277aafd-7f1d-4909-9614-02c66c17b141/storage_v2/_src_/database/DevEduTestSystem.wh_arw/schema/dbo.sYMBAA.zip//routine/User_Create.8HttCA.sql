create procedure User_Create 
	@FirstName nvarchar(30),
	@LastName nvarchar(30),
	@BirthDate date,
	@Login nvarchar(30),
	@Password nvarchar(30),
	@Email nvarchar(60),
	@Phone nvarchar(12)
	as
begin
insert into [User] values(@FirstName,@LastName,@BirthDate,@Login,@Password,@Email,@Phone)
end
go

