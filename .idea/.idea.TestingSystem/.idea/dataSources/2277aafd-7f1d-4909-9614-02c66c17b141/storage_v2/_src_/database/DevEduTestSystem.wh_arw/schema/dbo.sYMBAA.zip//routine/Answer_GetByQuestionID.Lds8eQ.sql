CREATE PROCEDURE Answer_GetByQuestionID
	@questionId INT
AS
	BEGIN
		SELECT * FROM Answer
		WHERE QuestionID=@questionId
	END
go

