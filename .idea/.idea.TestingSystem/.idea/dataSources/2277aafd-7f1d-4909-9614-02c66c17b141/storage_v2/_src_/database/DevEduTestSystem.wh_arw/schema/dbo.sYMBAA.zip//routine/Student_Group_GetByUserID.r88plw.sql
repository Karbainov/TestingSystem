CREATE PROCEDURE Student_Group_GetByUserID
@UserID int
AS
BEGIN
SELECT * FROM Student_Group WHERE UserID=@UserID
END
go

