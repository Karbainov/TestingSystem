CREATE PROCEDURE Attempt_Question_Answer_GetAll
AS
BEGIN
    SELECT *
    FROM Attempt_Question_Answer
END;
go

