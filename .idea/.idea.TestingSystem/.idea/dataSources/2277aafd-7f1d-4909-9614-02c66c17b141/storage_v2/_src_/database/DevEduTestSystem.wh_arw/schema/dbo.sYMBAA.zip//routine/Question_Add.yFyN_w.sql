CREATE PROCEDURE Question_Add
	@TestID int,
    @Value NVARCHAR(2500),
	@TypeID int,
	@AnswersCount TINYINT,
	@Weight TINYINT
AS
BEGIN
INSERT INTO Question VALUES (@TestID, @Value, @TypeID, @AnswersCount, @Weight)
END;
go

