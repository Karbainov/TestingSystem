CREATE procedure [dbo].[User_Role_ReadByUserID]
	@UserID int
	as
begin
select RoleID from User_Role where UserID=@UserID
end
go

