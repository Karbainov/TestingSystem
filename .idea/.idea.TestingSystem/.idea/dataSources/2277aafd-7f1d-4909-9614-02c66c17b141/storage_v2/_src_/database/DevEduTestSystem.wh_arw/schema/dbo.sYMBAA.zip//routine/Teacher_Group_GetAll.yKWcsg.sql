CREATE PROCEDURE Teacher_Group_GetAll
AS
BEGIN 
SELECT * FROM Teacher_Group
END
go

