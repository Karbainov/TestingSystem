CREATE PROCEDURE Student_Group_Add
@UserID int,
@GroupID int
AS
BEGIN
INSERT INTO Student_Group VALUES (@UserID,@GroupID)
END
go

