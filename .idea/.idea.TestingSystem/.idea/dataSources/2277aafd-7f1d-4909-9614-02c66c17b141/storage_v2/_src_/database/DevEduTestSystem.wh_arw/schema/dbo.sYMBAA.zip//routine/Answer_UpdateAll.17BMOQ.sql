CREATE PROCEDURE Answer_UpdateAll
	@id INT,
	@questionId INT,
	@value nvarchar(250),
	@correct BIT
AS
	BEGIN
		UPDATE Answer
		SET QuestionID=@questionId, Value=@value, Correct=@correct
		WHERE ID=@id
	END
go

