create procedure User_Read
@id int
as
begin
select * from [User] where ID = @id
end
go

