CREATE procedure [dbo].[Users_Roles_Delete]
	@RoleID int,
	@UserID int
	as
begin
delete from User_Role where RoleID=@RoleID and UserID = @UserID
end
go

