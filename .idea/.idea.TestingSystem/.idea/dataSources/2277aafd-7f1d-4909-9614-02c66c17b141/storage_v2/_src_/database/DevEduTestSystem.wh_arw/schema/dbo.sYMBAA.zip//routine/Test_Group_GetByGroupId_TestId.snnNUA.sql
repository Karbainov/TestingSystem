CREATE PROCEDURE Test_Group_GetByIdGroup_TestID
@idGroup INT,
@idTest INT
AS
BEGIN 
	SELECT * FROM Test_Group WHERE GroupID=@idGroup AND TestID=@idTest;
END
go

