
CREATE PROCEDURE Attempt_GetByUserID
     @userID   INT
        
AS
BEGIN
    SELECT *    FROM Attempt
    WHERE UserID = @userID  ;
END;
go

