create procedure Answer_GetCorrectByQuestionID 
	@QuestionID int
	as
begin
select * from Answer where Answer.QuestionID=@QuestionID and Answer.Correct='True' 
end
go

