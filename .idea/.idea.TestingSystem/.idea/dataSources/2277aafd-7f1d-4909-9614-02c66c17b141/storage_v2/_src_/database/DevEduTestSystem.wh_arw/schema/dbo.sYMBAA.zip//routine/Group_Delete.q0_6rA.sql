CREATE PROCEDURE Group_DeleteId
	@idGroup INT
	AS
	BEGIN 
	DELETE [Group] 
	WHERE(ID=@idGroup);
	END
go

