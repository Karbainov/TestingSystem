CREATE procedure [dbo].[Role_ReadById]
	@ID int
	as
begin 
select Name from Role where ID=@ID
end
go

