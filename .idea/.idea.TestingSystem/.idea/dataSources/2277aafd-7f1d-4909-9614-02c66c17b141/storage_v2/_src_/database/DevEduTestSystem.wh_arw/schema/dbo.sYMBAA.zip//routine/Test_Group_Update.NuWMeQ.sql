CREATE PROCEDURE Test_Group_Update
	@idGroup INT,
	@idTest INT,
	@startDate DATE,
	@endDate DATE,
	@idTestsGroup INT
	AS
	BEGIN
	UPDATE Test_Group
	SET GroupID =@idGroup, TestID=@idTest,StartDate=@startDate,EndDate=@endDate
	WHERE(ID=@idTestsGroup);
	END
go

