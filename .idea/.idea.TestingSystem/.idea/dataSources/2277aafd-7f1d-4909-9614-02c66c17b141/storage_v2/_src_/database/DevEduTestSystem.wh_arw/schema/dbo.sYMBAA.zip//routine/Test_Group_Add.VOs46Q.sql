CREATE PROCEDURE Test_Group_Add
	@idGroup INT,
	@idTest INT,
	@startDate DATE,
	@endDate DATE
	AS
	BEGIN
	INSERT INTO Test_Group VALUES (@idGroup, @idTest,@startDate,@endDate)
	END
go

