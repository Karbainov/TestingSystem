CREATE PROCEDURE Test_Group_DeleteIdTest
	@idTest INT
	AS
	BEGIN 
	DELETE Test_Group 
	WHERE(TestID=@idTest);
	END
go

