CREATE PROCEDURE Test_Group_GetById
	@idTestsGroup INT
	AS
	BEGIN
	SELECT * FROM Test_Group WHERE ID=@idTestsGroup;
	END
go

