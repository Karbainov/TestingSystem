create procedure User_Update 
@id int,
	@FirstName nvarchar(30),
	@LastName nvarchar(30),
	@BirthDate date,
	@Login nvarchar(30),
	@Password nvarchar(30),
	@Email nvarchar(60),
	@Phone nvarchar(12)
	as
	begin
	update [User]

set FirstName = @FirstName,LastName=@LastName, BirthDate = @BirthDate, Login=@Login, Password=@Password,Email=@Email, Phone = @Phone
where ID = @id
end
go

