CREATE PROCEDURE Student_Group_GetByGroupID
@GroupID int
AS
BEGIN
SELECT * FROM Student_Group WHERE GroupID=@GroupID
END
go

