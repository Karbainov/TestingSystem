CREATE procedure [dbo].[User_Role_ReadByRoleID]
	@RoleID int
	as
begin
select UserID from User_Role where RoleID = @RoleID
end
go

