CREATE PROCEDURE Question_GetByTypeID @TypeID int AS
BEGIN
SELECT * FROM Question WHERE TypeID = @TypeID;
END;
go

