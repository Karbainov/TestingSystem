create procedure Role_Read as
begin
select * from Role
end
go

