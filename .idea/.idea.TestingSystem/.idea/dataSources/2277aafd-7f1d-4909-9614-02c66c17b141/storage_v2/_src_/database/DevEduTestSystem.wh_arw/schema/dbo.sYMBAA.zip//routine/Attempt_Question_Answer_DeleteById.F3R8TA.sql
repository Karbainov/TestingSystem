CREATE PROCEDURE Attempt_Question_Answer_DeleteById
	@Id int
AS
BEGIN
	DELETE Attempt_Question_Answer
WHERE ID = @Id
END;
go

