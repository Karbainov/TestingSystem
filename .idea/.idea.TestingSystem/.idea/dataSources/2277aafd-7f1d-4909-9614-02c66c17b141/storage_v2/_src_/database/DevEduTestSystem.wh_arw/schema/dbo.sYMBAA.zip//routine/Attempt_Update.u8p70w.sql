
CREATE PROCEDURE Attempt_Update
        @id INT,
	    @number TINYINT,
        @userID   int,
        @testID   int,
        @userResult TINYINT,
        @dateTime DATETIME,
	    @durationTime TIME(7)
        
AS
BEGIN
UPDATE Attempt
SET 
    Number = @number,
    TestID = @testID,
    UserID = @userID ,
	UserResult = @userResult,
	DateTime = @dateTime,
	DurationTime = @durationTime
WHERE ID = @Id
END;
go

