CREATE PROCEDURE Attempt_Question_Answer_GetByQuestionId
	@questionId INT
AS
BEGIN
    SELECT *
    FROM Attempt_Question_Answer
    WHERE QuestionID = @questionId;
END;
go

