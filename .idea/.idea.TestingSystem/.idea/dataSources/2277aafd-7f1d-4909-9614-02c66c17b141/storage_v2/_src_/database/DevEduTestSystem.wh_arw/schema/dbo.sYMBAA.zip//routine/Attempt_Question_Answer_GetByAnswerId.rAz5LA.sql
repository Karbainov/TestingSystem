CREATE PROCEDURE Attempt_Question_Answer_GetByAnswerId
	@answerId INT
AS
BEGIN
    SELECT *
    FROM Attempt_Question_Answer
    WHERE AnswerID = @answerId;
END;
go

