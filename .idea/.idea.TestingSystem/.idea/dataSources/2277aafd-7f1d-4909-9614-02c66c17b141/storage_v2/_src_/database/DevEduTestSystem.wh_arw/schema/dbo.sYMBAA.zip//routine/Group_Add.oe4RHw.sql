CREATE PROCEDURE Group_ADD
	@name NVARCHAR(60),
	@startDate DATE,
	@endDate DATE
	AS
	BEGIN
	INSERT INTO [Group] VALUES (@name, @startDate, @endDate)
	END
go

