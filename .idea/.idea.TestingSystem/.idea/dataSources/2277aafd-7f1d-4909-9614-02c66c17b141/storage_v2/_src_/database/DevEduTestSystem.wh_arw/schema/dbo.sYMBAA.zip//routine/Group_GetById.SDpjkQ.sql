CREATE PROCEDURE Group_GetById 
	@idGroup INT
	AS
	BEGIN
	SELECT * FROM [Group] WHERE ID=@idGroup;
	END
go

