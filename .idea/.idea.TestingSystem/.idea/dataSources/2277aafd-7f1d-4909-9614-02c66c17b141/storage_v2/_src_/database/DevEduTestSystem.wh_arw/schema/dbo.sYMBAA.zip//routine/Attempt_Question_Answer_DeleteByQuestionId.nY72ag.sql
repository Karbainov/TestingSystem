CREATE PROCEDURE Attempt_Question_Answer_DeleteByQuestionId
	@Id int
AS
BEGIN
	DELETE Attempt_Question_Answer
WHERE ID = @Id
END;
go

