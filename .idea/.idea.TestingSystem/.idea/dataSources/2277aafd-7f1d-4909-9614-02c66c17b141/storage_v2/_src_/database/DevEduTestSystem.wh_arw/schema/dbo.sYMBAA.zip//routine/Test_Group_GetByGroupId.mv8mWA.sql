CREATE PROCEDURE Test_Group_GetByIdGroup
	@idGroup INT
	AS
	BEGIN
	SELECT * FROM Test_Group WHERE GroupID=@idGroup;
	END
go

