CREATE procedure [dbo].[Group_GetByTeacherID]
	@TeacherID int
	as
begin
select [Group].* from [Group] inner join Teacher_Group on [Group].ID = Teacher_Group.GroupID where Teacher_Group.UserID = @TeacherID
end
go

