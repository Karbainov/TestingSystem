
CREATE PROCEDURE Attempt_Add
	    @number TINYINT,
        @userID   int,
        @testID   int,
        @userResult TINYINT,
        @dateTime DATETIME,
	    @durationTime TIME(7)
        

AS
BEGIN
INSERT INTO Attempt VALUES (@number, @userID, @testID, @userResult, @dateTime, @durationTime)
END;
go

