CREATE PROCEDURE Teacher_Group_GetByGroupID
@GroupID int
AS
BEGIN
SELECT * FROM Teacher_Group WHERE GroupID=@GroupID
END
go

