create procedure User_Delete
@id int
as
begin
delete from [User] where ID=@id
end
go

