CREATE PROCEDURE Test_Group_GetAll
	AS
	BEGIN
	SELECT * FROM Test_Group;
	END
go

