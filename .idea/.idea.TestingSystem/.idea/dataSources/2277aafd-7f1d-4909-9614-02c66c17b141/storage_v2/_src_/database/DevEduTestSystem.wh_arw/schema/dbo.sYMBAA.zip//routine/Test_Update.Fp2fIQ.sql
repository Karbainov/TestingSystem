CREATE PROCEDURE Test_Update
	@Id int,
	@name NVARCHAR(60),
	@duration TIME(7),	
	@score TINYINT
AS
BEGIN
UPDATE Test
SET Name = @name,
	DurationTime = @duration,	
	SuccessScore = @score
WHERE ID = @Id
END;
go

