
CREATE PROCEDURE Answer_Add
	@questionId INT,
	@value NVARCHAR(250),
	@correct BIT
AS
BEGIN
INSERT INTO Answer VALUES
(@questionId,@value,@correct)
END
go

