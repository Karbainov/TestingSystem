CREATE procedure [dbo].[Role_Update]
	@ID int,
	@Name nvarchar(30)
	as
begin
update Role
set Name =@Name
where ID = @ID
end
go

