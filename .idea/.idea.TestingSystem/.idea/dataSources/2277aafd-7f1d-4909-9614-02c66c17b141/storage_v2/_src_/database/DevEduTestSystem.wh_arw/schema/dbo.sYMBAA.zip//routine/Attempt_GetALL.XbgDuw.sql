
CREATE PROCEDURE Attempt_GetALL
        @id INT,
	    @number TINYINT,
        @userID   int,
        @testID   int,
        @userResult TINYINT,
        @dateTime DATETIME,
	    @durationTime TIME(7)
        
AS
BEGIN
    SELECT *
    FROM Attempt
END;
go

