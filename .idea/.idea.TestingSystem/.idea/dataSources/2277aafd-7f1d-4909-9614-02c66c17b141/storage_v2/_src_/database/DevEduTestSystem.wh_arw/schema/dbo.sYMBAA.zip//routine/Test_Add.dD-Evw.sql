CREATE PROCEDURE Test_Add
	@name NVARCHAR(60),
	@duration TIME(7),	
	@score TINYINT
AS
BEGIN
INSERT INTO Test VALUES (@name, @duration, @score)
END;
go

