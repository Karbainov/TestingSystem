CREATE procedure [dbo].[Test_Attempt_GetLate] 
	@UserID int
	as
begin
select [Test].* from Attempt inner join [Test] on Attempt.TestID = [Test].ID inner join Test_Group on [Test].ID = [Test_Group].TestID
and Attempt.UserID =@UserID and Attempt.[DateTime]>[Test_Group].EndDate
end
go

