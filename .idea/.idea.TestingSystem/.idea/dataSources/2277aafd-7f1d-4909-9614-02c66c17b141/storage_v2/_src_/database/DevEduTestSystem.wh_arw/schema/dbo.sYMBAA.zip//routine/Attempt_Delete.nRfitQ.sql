
CREATE PROCEDURE Attempt_Delete

@Id int
AS
BEGIN
DELETE Attempt
WHERE ID = @Id
END;
go

