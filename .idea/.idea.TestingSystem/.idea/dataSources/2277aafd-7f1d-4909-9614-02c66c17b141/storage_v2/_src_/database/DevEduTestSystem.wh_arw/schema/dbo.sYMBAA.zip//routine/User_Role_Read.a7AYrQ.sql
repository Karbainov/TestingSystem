create procedure User_Role_Read as
begin
select * from User_Role
end
go

