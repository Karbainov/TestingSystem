CREATE procedure [dbo].[Role_Delete] 
	@ID int
	as
begin
delete Role where ID = @ID
end
go

