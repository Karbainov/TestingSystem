CREATE PROC Type_Delete
	@TypeId int
AS
BEGIN
DELETE FROM Type
WHERE ID = @TypeId
END
go

