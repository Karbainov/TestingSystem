CREATE PROCEDURE Tag_Update
	@id int,
	@name NVARCHAR(30)
AS
BEGIN
	UPDATE Tag
	SET Name = @name
	WHERE ID = @id
END;
go

