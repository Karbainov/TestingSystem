CREATE PROCEDURE Question_GetByTestID @TestID int AS
BEGIN
SELECT * FROM Question WHERE TestID = @TestID;
END;
go

