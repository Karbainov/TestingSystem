CREATE PROCEDURE Teacher_Group_Add
@UserID int,
@GroupID int
AS
BEGIN
INSERT INTO Teacher_Group VALUES (@UserID,@GroupID)
END
go

