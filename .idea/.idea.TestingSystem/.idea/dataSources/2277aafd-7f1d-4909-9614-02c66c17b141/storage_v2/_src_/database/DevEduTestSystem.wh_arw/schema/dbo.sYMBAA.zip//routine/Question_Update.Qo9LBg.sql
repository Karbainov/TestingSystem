CREATE PROCEDURE Question_Update
	@Id int,
	@TestID int,
    @Value NVARCHAR(2500),
	@TypeID int,
	@AnswersCount TINYINT,
	@Weight TINYINT
AS
BEGIN
UPDATE Question
SET TestID = @TestID,
    Value = @Value,
	TypeID = @TypeID,
	AnswersCount = @AnswersCount,
	Weight = @Weight
WHERE ID = @Id
END;
go

