CREATE PROCEDURE Attempt_Question_Answer_GetByAttemptId
	@attemptId INT
AS
BEGIN
    SELECT *
    FROM Attempt_Question_Answer
    WHERE AttemptID = @attemptId;
END;
go

