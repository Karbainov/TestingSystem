CREATE PROCEDURE Group_UpdateId
	@name NVARCHAR(60),
	@startDate DATE,
	@endDate DATE,
	@idGroup INT
	AS
	BEGIN
	UPDATE [Group]
	SET Name=@name, StartDate=@startDate,EndDate=@endDate
	WHERE(ID=@idGroup);
	END
go

