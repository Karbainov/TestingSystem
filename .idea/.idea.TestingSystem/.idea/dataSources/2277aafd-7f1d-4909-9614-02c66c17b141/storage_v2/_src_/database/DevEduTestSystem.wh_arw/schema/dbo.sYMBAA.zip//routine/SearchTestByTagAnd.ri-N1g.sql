CREATE PROCEDURE SearchTestByTagAnd
	@tag1 nvarchar(30),
	@tag2 nvarchar(30),
	@tag3 nvarchar(30)
AS
BEGIN
SELECT Test.Name FROM Test
	INNER JOIN Test_Tag ON Test_Tag.TestID=Test.ID
	INNER JOIN Tag ON Tag.ID=Test_Tag.TagID
	WHERE Tag.Name=@tag1 AND Tag.Name=@tag2 AND Tag.Name=@tag3
END
go

