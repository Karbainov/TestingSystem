CREATE PROCEDURE Attempt_GetByUserIdTestId 
	@userId int,
	@testId int
AS
BEGIN
SELECT Number AS 'Номер попытки', DateTime AS 'Дата и время прохождения', UserResult AS 'Результат', DurationTime AS 'Длительность прохождения'
FROM Attempt 
WHERE UserID = @userId AND TestID = @testId
END;
go

