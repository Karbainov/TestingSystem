CREATE PROCEDURE FeedBackQuestion_GetByUserDate 
	@userId int,
	@date datetime
AS
BEGIN
SELECT FeedBack.Message AS 'FeedBack', Question.Value AS 'Вопрос'
FROM Feedback 
JOIN Question ON Question.ID = Feedback.QuestionID
WHERE UserID = @userId AND [DateTime] = @date 
END;
go

