CREATE PROCEDURE Test_Group_DeleteIdGroup
	@idGroup INT
	AS
	BEGIN 
	DELETE Test_Group 
	WHERE(GroupID=@idGroup);
	END
go

