CREATE PROCEDURE Attempt_Question_Answer_Add
	@attemptId INT,
	@questionId INT,
	@answerId INT
AS
BEGIN
	INSERT INTO Attempt_Question_Answer VALUES (@attemptId, @questionId, @answerId)
END;
go

