
CREATE PROCEDURE Type_Add
	@Name nvarchar(30)
AS
BEGIN
INSERT INTO Type (Name)
	VALUES (@Name)
END
go

