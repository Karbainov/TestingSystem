CREATE PROCEDURE Question_DeleteFromTest	
	@questionId int,
	@testId int
AS
BEGIN
DELETE Attempt_Question_Answer WHERE QuestionID = @questionId
DELETE Answer WHERE QuestionID = @questionId
DELETE Feedback WHERE QuestionID = @questionId
DELETE Question WHERE ID = @questionId
SELECT * FROM Attempt WHERE TestID = testId
END;
go

