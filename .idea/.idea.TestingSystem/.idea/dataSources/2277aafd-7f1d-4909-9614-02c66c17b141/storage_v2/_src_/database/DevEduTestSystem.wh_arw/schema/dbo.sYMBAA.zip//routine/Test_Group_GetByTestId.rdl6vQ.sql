CREATE PROCEDURE Test_Group_GetByIdTest
	@idTests INT
	AS
	BEGIN
	SELECT * FROM Test_Group WHERE TestID=@idTests;
	END
go

