CREATE PROCEDURE Feedback_updateAll
@ID INT,
@UserID INT,
@QuestionID INT,
@Message NVARCHAR(2500)
AS
 BEGIN
  UPDATE Feedback
  SET [Message]=@Message
  WHERE ID=@ID
END;
go

