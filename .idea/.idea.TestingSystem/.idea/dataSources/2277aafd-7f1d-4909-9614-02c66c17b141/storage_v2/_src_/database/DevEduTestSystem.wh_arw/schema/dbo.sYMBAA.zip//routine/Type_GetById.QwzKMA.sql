CREATE PROC Type_GetById
	@TypeId int
AS
BEGIN
	SELECT ID, Name FROM Type
	WHERE (ID = @TypeId)
END
go

