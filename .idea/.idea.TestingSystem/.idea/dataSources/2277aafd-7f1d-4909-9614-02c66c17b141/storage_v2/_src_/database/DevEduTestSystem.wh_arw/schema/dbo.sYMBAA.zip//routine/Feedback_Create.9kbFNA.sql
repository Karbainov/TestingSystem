CREATE PROCEDURE Feedback_Create
@UserID int,
@QuestionID int,
@Message NVARCHAR(2500)
AS
BEGIN
INSERT INTO Feedback VALUES ( @UserID, @QuestionID, @Message)
END
go

